##获取ck
~~~
http://192.168.41.76:6899/login/guest?deviceid=1
~~~
##wiki
~~~
http://wiki.boss.com/wiki/index.php/$crazy_bet/match/football/detail_%E8%B6%B3%E7%90%83%E6%AF%94%E8%B5%9B%E8%B5%9B%E4%BA%8B%E8%AF%A6%E6%83%85
~~~
###例子
~~~
http://192.168.41.76:6899/match/football/detail?ck=MTAwMjkwOTJmYzA5OWQ5YWFjNGM3MTcxMTNiMzk4MjNkMjA5N2Y2&matchid=757945 
~~~
###服务号账号
3157085145@qq.com	Crazy500.com
AppID(应用ID) wx86d590e6cf755764   AppSecret （应用密钥）  需重置才行

###  球球是道
service@10.0.0.31:/home/service/touch/crazy_qqsd.git