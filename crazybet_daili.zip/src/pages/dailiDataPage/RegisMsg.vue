<template>
    <div>
        <p>注册信息页和个人信息</p>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                title: ''
            }
        },
        watch: {},
        methods: {},
        computed: {},
        mounted(){

        }
    }
</script>
<style>
</style>
