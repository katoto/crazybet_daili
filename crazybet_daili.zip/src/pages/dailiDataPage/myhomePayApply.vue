<template>
    <div id="app">
        <p>myhomePayApply</p>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                title: '我是頭部'
            }
        },
        watch: {},
        methods: {},
        computed: {},
        mounted(){

        }
    }
</script>
<style>
</style>
